#include <iostream>
#include <cctype>
#include <cstring>

using namespace std;
const int maxsize = 100;
bool kt(*p)
{
    while (*p)
    {
        if(*p)
    }
}

int main()
{
	char s[maxsize], s1[maxsize];
	cout << "Nhap chuoi ky tu:";
	cin.getline(s, 100);
	char *p = s;
	cout <<"\nHo ten cua nguoi dung la: "<< p;
	return 0;
	

}