#include <iostream>
#include <string>

using namespace std;

int main()
{
    string s,s1,s2;
    cout <<"Nhap vao ho: ";
    getline(cin,s);
    cout <<"\nNhap vao ten lot:";
    getline(cin,s1);
    cout <<"\nNhap vao ten:";
    getline(cin,s2);
    cout <<"\nTen day du cua ban la: "<<s <<" "<<s1<<" "<<s2;
}
