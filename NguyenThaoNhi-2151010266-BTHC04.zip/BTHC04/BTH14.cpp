#include <iostream>
#include <string>

using namespace std;

int main()
{
    string s,s1="";
    char*p;
    cout <<"Nhap vao chuoi: ";
    getline(cin,s);
    cout<<"\nNhap vao tu: ";
    getline(cin,s1);
    
    cout <<"\nChuoi nguoc lai la: "<<s1;
    return 0;
    system("pause");
}